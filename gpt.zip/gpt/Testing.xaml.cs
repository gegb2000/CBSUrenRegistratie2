namespace CBSUrenRegistratie2;

public partial class Testing : ContentPage
{
	public Testing()
	{
		InitializeComponent();
	}
}