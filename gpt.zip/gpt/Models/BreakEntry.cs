﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBSUrenRegistratie2.Models
{
    
        public class BreakEntry
        {
            public int BreakId { get; set; }
            public TimeSpan StartBreakTime { get; set; }
            public TimeSpan EndBreakTime { get; set; }
        }
    
}
