namespace CBSUrenRegistratie2.Views;

public partial class ProjectManagementPage : ContentPage
{
	public ProjectManagementPage()
	{
		InitializeComponent();
	}
}